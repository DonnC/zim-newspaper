from newspaperzw import news
from newspaperzw import Provider

__name__    = "zim-newspaper"
__version__ = "1.0.0"
__author__  = "Donald Chinhuru"